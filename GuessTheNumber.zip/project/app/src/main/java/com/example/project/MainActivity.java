package com.example.project;

import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {
    EditText num;
    TextView txt;
    int counter=3,flag=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        num = findViewById(R.id.inputId);
        txt=(TextView)findViewById(R.id.tv);

    }
    Random ran = new Random();
    int random_number = ran.nextInt(10);


    public void btnclick(View view) {

        String user_string = num.getText().toString();


        if (user_string.isEmpty()) {

            Toast.makeText(this, "Enter a number", Toast.LENGTH_SHORT).show();

        } else {
            int user_number = Integer.parseInt(user_string);

            if (user_number > random_number) {
                Toast.makeText(this, "Go Less!", Toast.LENGTH_SHORT).show();
                txt.setVisibility(View.VISIBLE);
                txt.setBackgroundColor(Color.RED);
                counter--;
                txt.setText(Integer.toString(counter));
            } else if (user_number < random_number) {
                Toast.makeText(this, "Go Higher!", Toast.LENGTH_SHORT).show();
                txt.setVisibility(View.VISIBLE);
                txt.setBackgroundColor(Color.RED);
                counter--;
                txt.setText(Integer.toString(counter));
            } else if (user_number == random_number) {
                Toast.makeText(MainActivity.this, "You guessed number right!!! YOU ARE GENIUS", Toast.LENGTH_SHORT).show();
                txt.setVisibility(View.VISIBLE);
                txt.setBackgroundColor(Color.RED);
                counter--;
                flag = 1;
                txt.setText(Integer.toString(counter));
                view.setEnabled(false);
            }
            if (flag == 0) {
                if (counter == 0) {
                    Toast.makeText(MainActivity.this, "Number of Attempts exceeded" + " Reguess the number", Toast.LENGTH_LONG).show();
                    txt.setVisibility(View.VISIBLE);
                    txt.setBackgroundColor(Color.RED);
                    counter = 3;
                    txt.setText(Integer.toString(counter));

                }
            }

        }
    }


}





